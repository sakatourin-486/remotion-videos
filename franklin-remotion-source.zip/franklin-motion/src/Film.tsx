import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,staticFile,delayRender,continueRender} from 'remotion';
import {useTime} from './lib/motion';
import {COLOR as C,FONT} from './spec';
import {Scene01} from './scenes/Scene01';
import {Scene02} from './scenes/Scene02';
export const Film:React.FC=()=>{const {t}=useTime();const [h]=useState(()=>delayRender('Load Chinese font'));useEffect(()=>{const f=new FontFace('NotoLocal',`url(${staticFile('NotoSansSC.otf')})`);f.load().then(v=>{(document.fonts as FontFaceSet & {add:(font:FontFace)=>void}).add(v);continueRender(h)});},[h]);return <AbsoluteFill style={{background:C.bg,fontFamily:FONT}}><Audio src={staticFile('score.wav')} volume={.65}/><svg viewBox="0 0 1920 1080" width="100%" height="100%"><Scene01 t={t}/><Scene02 t={t}/><path d="M180 1025H1740" stroke="#DCD8CC" strokeWidth={2}/><path d={`M180 1025H${180+1560*Math.min(t/29.7,1)}`} stroke={C.coral} strokeWidth={3}/></svg></AbsoluteFill>};
