// S01–S06: thirty-second school example, Chinese captions, original flat illustration.
export const FILM = {duration: 30, fps: 60, width: 3840, height: 2160, bpm: 96, sound: true};
export const COLOR = {bg:'#F5F1E8',ink:'#242C32',teal:'#28665F',coral:'#CD624A',muted:'#777D78',paper:'#FFFCF5'};
export const FONT = 'NotoLocal, sans-serif';
export const T = {request:3.75,pass:7.5,thanks:10,explain:15,title:22.5,end:26.25};
export const COPY = {school:'马陵中学的一名学生',title:'富兰克林效应'};
