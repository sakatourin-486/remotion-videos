import React from 'react';
import {Book,Text,RevealText} from '../lib/film';
import {prog,EASE,mix} from '../lib/motion';
import {COLOR as C,COPY} from '../spec';
export const Scene02:React.FC<{t:number}>=({t})=>{if(t<14)return null;const enter=prog(t,14,1,EASE.inOut);const named=prog(t,22.5,1,EASE.inOut);const end=t>=26.25;return <g transform={`translate(${(1-enter)*1920} 0)`}>
<Text x={180} y={142} size={25} color={C.muted} anchor="start">{end?'03 / 把理解带回生活':'02 / 行为，也会影响态度'}</Text>
{!end&&<><RevealText t={t} at={15} x={960} y={265} size={60}>为什么，帮忙的人也可能更有好感？</RevealText>
<g transform={`translate(0 ${-named*45})`}><Book x={390} y={510} scale={1.25}/><Text x={390} y={715} size={44}>我帮了他</Text>
<path d="M560 515H790m-22-17 22 17-22 17" fill="none" stroke={C.coral} strokeWidth={5} strokeDasharray={420} strokeDashoffset={420*(1-prog(t,16.25,1.1,EASE.inOut))}/>
<RevealText t={t} at={17.5} x={1120} y={490} size={58} color={C.teal}>“也许，他值得亲近。”</RevealText><RevealText t={t} at={18.75} x={1120} y={565} size={34} color={C.muted}>一种解释：让态度与行为保持一致</RevealText>
</g>
{t<22.5&&<Text x={960} y={950} size={42}>我们有时会调整态度，来解释自己的行为。</Text>}
{t>=22.5&&<><RevealText t={t} at={22.5} x={960} y={800} size={92} color={C.coral} weight={700}>{COPY.title}</RevealText><Text x={960} y={950} size={42}>帮助过你的人，可能因此更喜欢你。</Text></>}
</>}
{end&&<><Book x={960} y={365} scale={.8}/><RevealText t={t} at={26.25} x={960} y={600} size={83} weight={700}>让关系，从一次小帮忙开始。</RevealText><RevealText t={t} at={26.875} x={960} y={713} size={43} color={C.teal}>真诚请求 · 力所能及 · 认真致谢</RevealText><Text x={960} y={905} size={38} color={C.muted}>这是一种可能的心理倾向，并非必然。</Text><Text x={960} y={980} size={23} color={C.muted}>研究线索：Jecker &amp; Landy, 1969 · 校园情节为虚构示例</Text></>}
</g>};
