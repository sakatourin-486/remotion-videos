import React from 'react';
import {Pair,Text,RevealText} from '../lib/film';
import {prog,EASE,mix} from '../lib/motion';
import {COLOR as C,COPY} from '../spec';
export const Scene01:React.FC<{t:number}>=({t})=>{if(t>=15)return null;const out=prog(t,14,1,EASE.inOut);return <g transform={`translate(${-out*1920} 0)`}>
<Text x={180} y={142} size={25} anchor="start" color={C.muted}>01 / 一次小小的求助</Text>
<RevealText t={t} at={t<3.75?0:t<10?3.75:10} x={960} y={260} size={64} weight={700}>{t<3.75?'他和那位同学，还不太熟。':t<10?'“能借我看看你的笔记吗？”':'一次帮忙之后，距离近了一点。'}</RevealText>
<path d="M410 770H1500" stroke="#C9C9BC" strokeWidth={3}/><path d="M440 360V750M1475 360V750" stroke="#E1DFD3" strokeWidth={3}/><path d="M440 380H700M1220 380H1475" stroke="#E1DFD3" strokeWidth={3}/>
<Pair t={t}/>
{t<3.75&&<><Text x={600} y={847} size={37} color={C.coral}>{COPY.school}</Text><Text x={1320} y={847} size={37} color={C.teal}>不太熟的同学</Text></>}
{t>=3.75&&t<7.5&&<><path d="M795 820h300" stroke={C.coral} strokeWidth={3} strokeDasharray="7 12" strokeDashoffset={-t*24}/><Text x={960} y={870} size={30} color={C.muted}>一个力所能及的小请求</Text></>}
{t>=8.75&&t<10&&<Text x={1310} y={410} size={42} color={C.teal}>“可以。”</Text>}
{t>=10&&<><RevealText t={t} at={10} x={800} y={850} size={42} color={C.coral}>“谢谢，写得真清楚！”</RevealText><path d="M910 640q110-75 220 0" fill="none" stroke={C.teal} strokeWidth={4} strokeDasharray="8 10" strokeDashoffset={-t*14}/></>}
<Text x={960} y={950} size={42}>{t<3.75?'先从马陵中学的一名学生说起。':t<7.5?'有一天，他向对方借了一次笔记。':t<10?'他把笔记递了过去。':'后来，对方可能更愿意和他聊天。'}</Text>
</g>};
