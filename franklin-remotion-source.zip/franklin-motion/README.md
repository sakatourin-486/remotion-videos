# 富兰克林效应 · 30 秒 Remotion 试片

校园虚构示例：马陵中学的一名学生，向不太熟的同学借笔记。
3840×2160，60fps，30秒，中文字幕与原创合成配乐，无人声旁白。

运行：
```
npm install
npm run studio
npm run render
npm run check
```

成片输出 `out/film.mp4`。分镜、素材结构与资料线索见 DESIGN.md。
中文字体 Noto Sans CJK SC，采用 SIL Open Font License 1.1。
